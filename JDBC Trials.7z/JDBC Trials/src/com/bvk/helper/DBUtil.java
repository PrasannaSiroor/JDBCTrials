package com.bvk.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connCustomer;
	
	public static Connection createConnection(){
		ResourceBundle resourceOracle = ResourceBundle.getBundle("oracle");
		String url = resourceOracle.getString("url");
		String username = resourceOracle.getString("username");
		String password = resourceOracle.getString("password");
		String driver = resourceOracle.getString("driver");
				
		try{
			Class.forName(driver);
			
			connCustomer = DriverManager.getConnection(url, username, password);
		}catch(ClassNotFoundException cnfe){
			System.out.println("Driver for Oracle not found: " + cnfe.getMessage());
		}catch(SQLException se){
			System.out.println("Problem with database. " + se.getMessage());
		}
		return connCustomer;
	}
	
	public static void closeConnection(){
		try{
			if(connCustomer != null){
				connCustomer.close();
			}
		}catch(SQLException se){
			System.out.println("Prorblem in closing connection with Oracle:"
					+ " "+se.getMessage());
		}
	}
}