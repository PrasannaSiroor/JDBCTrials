package com.bvk.client;

public class Client4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int empid = 5;
		
		Dao dao = new Dao();
		
		dao.retrieveEmployee(empid);
	}
}
