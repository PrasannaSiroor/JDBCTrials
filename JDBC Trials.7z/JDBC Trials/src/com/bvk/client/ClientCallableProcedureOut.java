package com.bvk.client;

import java.util.Scanner;

import com.bvk.dao.EmployeeDAO;
import com.bvk.dao.EmployeeDAOImpl;

public class ClientCallableProcedureOut {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int empid = 0;
		float salary = 0.0f;

		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		
		System.out.print("Enter Employee ID: ");
		empid = sc.nextInt();
				sc.nextLine();

		salary = employeeDAO.getSalary(empid);
		
		System.out.println(salary);
	}
}