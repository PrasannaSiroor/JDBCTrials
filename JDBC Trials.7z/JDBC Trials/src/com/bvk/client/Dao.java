package com.bvk.client;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class Dao {
	private Connection connEmp;
	
	public Dao(){
		
	}
	
	public int insertUsingStatement(int empid, String name, float salary){
		int status = 0;
		String query = new String("INSERT INTO emp1 VALUES("+empid+",'"+name+"',"+salary+")");
		//INSERT INTO emp VALUES(4,'xyz',50000)
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			Statement st = connEmp.createStatement();
			status = st.executeUpdate(query);
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				if(connEmp != null){
					connEmp.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}
	
	public int insertUsingPreparedStatement(int empid, String name, float salary){
		int status = 0;
		String query = new String("INSERT INTO emp1 VALUES(?,?,?)");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			PreparedStatement pst = connEmp.prepareStatement(query);
			
			pst.setInt(1, empid);
			pst.setString(2, name);
			pst.setFloat(3, salary);
			
			status = pst.executeUpdate();
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}
	
	public int insertUsingCallableStatement(int empid, String name, float salary){
		int status = 0;
		String query = new String("{CALL insertit(?,?,?)}");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			CallableStatement cst = connEmp.prepareCall(query);
			
			cst.setInt(1, empid);
			cst.setString(2, name);
			cst.setFloat(3, salary);
			
			status = cst.executeUpdate();
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}
	
	public void retrieveEmployee(int empid){
		String query = new String("{CALL getemp(?,?)}");
		String name = null;
		float salary = 0.0f;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			CallableStatement cst = connEmp.prepareCall(query);
			
			cst.setInt(1, empid);
			cst.registerOutParameter(2, Types.FLOAT);
			
			cst.execute();
			
			salary = cst.getFloat(2);
			
			System.out.println("Employee Id: " + empid + "\n" +"Salary: "+salary);
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void updateSalary(int empid, float salary){
		String query = new String("{CALL updateSalary(?,?)}");
						
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			CallableStatement cst = connEmp.prepareCall(query);
			
			cst.setInt(1, empid);
			cst.setFloat(2, salary);
			cst.registerOutParameter(2, Types.FLOAT);
			
			cst.execute();
			
			salary = cst.getFloat(2);
			
			System.out.println("Updated Salary is: "+salary);
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void returnSalary(int empid){
		String query = new String("{CALL ?:=getsal(?)}");
		double salary = 0.0f;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			CallableStatement cst = connEmp.prepareCall(query);
			cst.registerOutParameter(1, Types.DECIMAL);
			cst.setInt(2, empid);
			cst.execute();
			
			salary = cst.getDouble(1);
			
			System.out.println("Salary is: "+salary);
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void showRecords(){
		ResultSet rs = null;
		String query = new String("SELECT * FROM emp1");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "corp123");
			Statement st = connEmp.createStatement();
			rs = st.executeQuery(query);
			
			while(rs.next()){
				System.out.println("Employee Id: " + rs.getInt("empid"));
				System.out.println("Employee Name: " + rs.getString("name"));
				System.out.println("Employee Salary: " + rs.getFloat("salary"));
				System.out.println("===========================================================================================================");
			}
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
}