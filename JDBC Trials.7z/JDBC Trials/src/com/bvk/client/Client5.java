package com.bvk.client;

public class Client5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int empid = 5;
		float increment = 5000;
		Dao dao = new Dao();
		
		dao.updateSalary(empid, increment);*/
		
		int empid = 6;
		
		Dao dao = new Dao();
		
		dao.returnSalary(empid);
	}

}
